# Charge-SKRL Navigation — 完整技術規格書

> 版本: 2026-03-23 | Branch: `curriculum_navrl_reward`
> Commit: 見 `git rev-parse HEAD`

---

## 1. 訓練設定與實驗可重現性

### 1.1 演算法

| 項目 | 值 |
|------|-----|
| 演算法 | PPO (Proximal Policy Optimization) |
| 實作來源 | SKRL (v1.4+), PyTorch backend |
| Repo | `git@github.com:Toni-SM/skrl.git` |
| 自訂整合 | `wandb_trainer.py` (繼承 SequentialTrainer) |

### 1.2 PPO 超參數（精確值）

| 參數 | 值 | 備註 |
|------|-----|------|
| rollouts | 128 | 每次 PPO update 收集的 transitions |
| learning_epochs | 4 | 每輪 rollout 的梯度更新次數 |
| mini_batches | 8 | 每 epoch 的 batch 分割數 |
| discount_factor (γ) | 0.990 | Phase 1 初始值；課程動態調整 0.990→0.998 |
| GAE lambda (λ) | 0.95 | |
| learning_rate (初始) | 1e-4 | LinearLR scheduler |
| learning_rate (最終) | 3e-5 | = 初始 × 0.3 |
| LR scheduler | LinearLR | factor: 1.0→0.3, total_iters=7324 |
| gradient_clip (max_grad_norm) | 1.0 | |
| ratio_clip (ε) | 0.2 | PPO surrogate clipping |
| value_clip | 0.2 | |
| clip_predicted_values | False | |
| entropy_loss_scale | 0.01 | |
| value_loss_scale | 1.0 | |
| KL threshold | 0.0 | 停用 |
| rewards_shaper_scale | 1.0 | |
| time_limit_bootstrap | True | timeout 時 bootstrap value |
| state_preprocessor | RunningStandardScaler | 觀測正規化 |
| value_preprocessor | RunningStandardScaler | 價值正規化 |
| random_timesteps | 0 | |
| learning_starts | 0 | |
| memory | RandomMemory (unbounded) | |

### 1.3 訓練步數

| 項目 | 值 |
|------|-----|
| total_timesteps | 234,375 |
| PPO updates | 234,375 / 128 = 1,831 |
| total gradient steps | 1,831 × 4 = 7,324 |
| 預設 num_envs | 256（可 CLI 覆蓋） |
| total env steps | 234,375 × 256 = 60,000,000 |

### 1.4 Seed

| 項目 | 值 |
|------|-----|
| 預設 seed | 42 |
| CLI 覆蓋 | `--seed N`（-1 = random） |
| 設定位置 | `env_cfg.seed` + `agent_cfg["seed"]` |

### 1.5 硬體

| 項目 | 值 |
|------|-----|
| GPU | NVIDIA GeForce RTX 5090 (32GB VRAM) |
| CPU | Intel Core Ultra 7 265K |
| RAM | 48 GB |
| OS | Ubuntu 24.04.3 LTS |
| CUDA | 13.0 |
| Driver | 580.126.09 |
| Isaac Sim | 5.1.0-rc.19 |
| PhysX | 107.3.26 |

### 1.6 Checkpointing

| 項目 | 值 |
|------|-----|
| 保存間隔 | SKRL 預設（每 N updates） |
| 保存內容 | Actor weights, Critic weights, optimizer state, RunningStandardScaler (mean/std/count) |
| Phase 2 載入 | `--checkpoint <path> --phase 2` |

---

## 2. 感測器與輸入觀測

### 2.1 LiDAR (Velodyne VLP-16)

| 參數 | 值 |
|------|-----|
| 類型 | MultiMeshRayCasterCfg |
| 垂直通道 | 16 |
| 垂直 FoV | -15° ~ +15° |
| 水平 FoV | -180° ~ +180° (全 360°) |
| 水平解析度 | 1.0° / ray |
| 總 ray 數 | 16 × 360 = 5,760 |
| 最大距離 | 20.0 m |
| 更新頻率 | 0.2 s (= control dt) |
| 安裝偏移 | (0, 0, 0.5) m (base_link 上方) |
| Ray alignment | yaw |
| 追蹤目標 | Ground (static), Wall_.* (track_transforms=True), Obstacle_.* (track_transforms=True) |

### 2.2 LiDAR 噪聲 (Domain Randomization)

| 參數 | 值 | 說明 |
|------|-----|------|
| displacement_std | 0.02 m | 每條 ray 的高斯距離雜訊 (±2cm 1σ) |
| hole_rate | 0.005 | ray 遺失機率 (0.5%) |
| distractor_rate | 0.002 | 幽靈點機率 (0.2%) |
| distractor_range | (0.2, 2.0) m | 幽靈點距離範圍 |

### 2.3 接觸感測器

| 參數 | 值 |
|------|-----|
| 安裝位置 | Robot/base_link |
| 更新頻率 | 每 sim step (0.01s) |
| 過濾目標 | Obstacle_.* |

### 2.4 觀測結構 (139D)

| 索引 | 欄位 | 維度 | 範圍 | 函數 |
|------|------|------|------|------|
| [0] | 正規化線加速度 ā | 1 | [-1, 1] | normalized_linear_acceleration |
| [1] | 正規化線速度 v̄ | 1 | [-1, 1] | normalized_linear_velocity |
| [2] | 角速度 ω_z | 1 | ~[-1.5, 1.5] rad/s | base_angular_velocity_z |
| [3] | 機器人半徑 | 1 | 0.35 (常數) | robot_radius_obs |
| [4:6] | 目標相對位置 (dx, dy) | 2 | body frame, m | goal_position_in_robot_frame |
| [6:78] | LiDAR 72 bins | 72 | [0, 1] 正規化 | lidar_vlp16_to_2d_bins |
| [78:138] | Top-10 障礙物 × 6D | 60 | (見下) | topk_obstacles_6d |
| [138] | 剩餘時間比例 | 1 | [0, 1] | time_remaining_ratio |

**障礙物 6D 結構**: `[dx, dy, vx, vy, radius, mask]`
- dx, dy: body frame 相對位置 (m)
- vx, vy: body frame 相對速度 (m/s)
- radius: 障礙物半徑 (m)
- mask: 1.0=可見, 0.0=遮擋/超距

**LiDAR bins**: 5,760 rays → min-pool to 72 bins (80 rays/bin) → 距離/r_max 正規化

### 2.5 觀測正規化

| 項目 | 值 |
|------|-----|
| 方法 | RunningStandardScaler |
| 公式 | obs_norm = (obs - running_mean) / (running_std + eps) |
| 更新 | 每步更新 running stats |
| 推論 | 凍結 stats |
| 已知風險 | NaN 輸入會永久汙染 stats → 已加 NaN 保護 |

---

## 3. 特徵抽取與網路架構

### 3.1 Feature Extractor (VLP16FeatureExtractor)

Actor 和 Critic **各自有獨立的 feature extractor**（models_separate=True）。

#### Branch 1: LiDAR Conv1d → 64D
```
Input: [B, 1, 72]
  Conv1d(1, 32, k=5, p=2) + ReLU → [B, 32, 72]
  Conv1d(32, 64, k=5, s=2, p=2) + ReLU → [B, 64, 36]
  Conv1d(64, 64, k=3, s=2, p=1) + ReLU → [B, 64, 18]
  AdaptiveMaxPool1d(1) → [B, 64, 1]
  Linear(64, 64) + LayerNorm(64) → [B, 64]
```

#### Branch 2: Obstacle MLP (Permutation-Invariant) → 32D
```
Input: [B, 10, 6]
  Per-object: Linear(6, 32) + ReLU + Linear(32, 32) + ReLU → [B, 10, 32]
  MaxPool(dim=1) → [B, 32]
  LayerNorm(32) → [B, 32]
```

#### Branch 3: State MLP (ego+goal+time) → 32D
```
Input: [B, 7]
  Linear(7, 32) + ReLU → [B, 32]
  Linear(32, 32) + ReLU → [B, 32]
  LayerNorm(32) → [B, 32]
```

#### Fusion
```
cat([64, 32, 32]) → [B, 128]
```

### 3.2 Actor Head (VLP16DiscretePolicy)

```
[B, 128] → Linear(128, 128) + ReLU → Linear(128, 38) → [B, 38] logits
```
- 38 logits = 19 (linear accel) + 19 (angular vel)
- Mixin: MultiCategoricalMixin (unnormalized_log_prob=True, reduction="sum")
- Weight init: Kaiming uniform (PyTorch 預設)

### 3.3 Critic Head (VLP16Value)

```
[B, 128] → Linear(128, 64) + ReLU → Linear(64, 32) + ReLU → Linear(32, 1)
```
- 最後一層: orthogonal_(gain=0.01), bias=constant_(-8.0)
- Mixin: DeterministicMixin

### 3.4 正規化

| 層 | 位置 |
|----|------|
| LayerNorm(64) | LiDAR branch 輸出 |
| LayerNorm(32) | Obstacle branch 輸出 |
| LayerNorm(32) | State branch 輸出 |
| 無 BatchNorm | |
| 無 Dropout | |

---

## 4. 動作空間與控制鏈

### 4.1 動作空間

| 參數 | 值 |
|------|-----|
| 類型 | MultiDiscrete([19, 19]) |
| 維度 | 2 (accel_idx, omega_idx) |
| 索引範圍 | [0, 18]，center=9 為零動作 |
| 映射 | idx → ratio = (idx - 9) / 9 ∈ [-1, 1] |

### 4.2 物理限制

| 參數 | 值 | 單位 |
|------|-----|------|
| v_max | 1.0 | m/s |
| a_max | 0.5 | m/s² |
| ω_max | 0.25π ≈ 0.785 | rad/s |
| 控制 dt | 0.2 | s |
| 速度域 | [-1.0, +1.0] | m/s（允許倒車） |

### 4.3 動態加速度邊界

```
a_min = max(-a_max, (-v_max - v_current) / dt)
a_max_actual = min(a_max, (v_max - v_current) / dt)

if ratio ≥ 0: accel = ratio × a_max_actual
if ratio < 0: accel = -ratio × a_min

v_next = clamp(v_current + accel × dt, -v_max, +v_max)
```

### 4.4 控制鏈

```
NN output [B, 38 logits]
  → Categorical sampling → [B, 2] indices
  → Index → ratio mapping
  → Dynamic accel bounds
  → Velocity integration
  → write_root_velocity_to_sim (differential drive)
```

### 4.5 Safety Shield (NavRL04, 可選)

| 參數 | 值 |
|------|-----|
| 類型 | Action post-processing (override apply_actions) |
| soft mode | d_safe < 1.2m 線性降速, < 0.55m 停止 |
| hard mode | d_safe < 0.55m 強制 v=0 |
| 影響 | 只裁切正向速度 (v > 0)，倒車不限 |
| 訓練/推論 | 訓練時即介入（agent 學到 shielded 行為） |

---

## 5. 環境、場景與 Curriculum

### 5.1 場景

| 參數 | Base (16×16m) | Curriculum (20×20m) |
|------|---------------|---------------------|
| 房間大小 | ±8m | ±10m |
| 邊界牆厚度 | 0.2m | 1.0m |
| 邊界牆高度 | 1.5m | 1.5m |
| 內部牆 | 6 (static AssetBaseCfg) | 8 slots (RigidObjectCfg, per-env 隨機) |
| 障礙物 | 10 (cuboid/cylinder) | 10 (同) |
| env_spacing | 18.0m | 22.0m |

### 5.2 模擬參數

| 參數 | 值 |
|------|-----|
| sim.dt | 0.01 s |
| decimation | 20 |
| control dt | 0.2 s (5 Hz) |
| episode_length | 45s~90s (課程動態) |
| max_steps/episode | 225~450 |
| gravity | 啟用 |
| ground friction | static=1.0, dynamic=1.0 |

### 5.3 障礙物

| 類型 | 數量 | 尺寸範圍 |
|------|------|---------|
| Cuboid | 5 | 0.4~0.7m × 0.4~0.7m × 0.9~1.4m |
| Cylinder | 5 | r=0.2~0.35m, h=0.8~1.5m |

動態障礙物行為: 隨機目標點移動, 速度 [0.3, 1.2] m/s, 每 10 步重新採樣速度, 8m 活動半徑

### 5.4 Domain Randomization

| 參數 | 範圍 |
|------|------|
| 質量縮放 | [0.85, 1.15] |
| 摩擦縮放 | [0.7, 1.3] |
| 質心偏移 | [-0.05, +0.05] m |
| 外力干擾 | [0, 3.0] N |
| LiDAR 距離雜訊 | ±0.02m (1σ) |
| LiDAR ray 遺失 | 0.5% |
| LiDAR 幽靈點 | 0.2% |

### 5.5 Reset 隨機化

| 參數 | Curriculum 20×20 |
|------|------------------|
| X | [-7.0, 7.0] m |
| Y | [-7.0, 7.0] m |
| Yaw | [-π, π] rad |
| 初速 vx | [-0.5, 0.5] m/s |
| 初速 vy | [-0.15, 0.15] m/s |
| 初速 ωz | [-0.5, 0.5] rad/s |

### 5.6 Curriculum (8 階段)

| Stage | Goals | Static | Dynamic | Empty% | γ | Episode | Walls | 升級 SR | 降級 SR |
|-------|-------|--------|---------|--------|---|---------|-------|---------|---------|
| 1 | 8 | 0 | 0 | 100% | 0.990 | 45s | 0-2 | >72% | N/A |
| 2 | 7 | 1 | 1 | 87% | 0.991 | 51s | 0-3 | >65% | <15% |
| 3 | 6 | 2 | 2 | 74% | 0.993 | 56s | 1-4 | >65% | <15% |
| 4 | 5 | 3 | 3 | 61% | 0.994 | 61s | 1-5 | >65% | <15% |
| 5 | 4 | 4 | 4 | 48% | 0.996 | 67s | 2-6 | >65% | <15% |
| 6 | 3 | 5 | 5 | 35% | 0.997 | 72s | 2-7 | >65% | <15% |
| 7 | 2 | 6 | 6 | 22% | 0.998 | 78s | 3-8 | >65% | <15% |
| 8 | 1 | 7 | 7 | 15% | 0.998 | 90s | 4-8 | 100% | <15% |

升級條件: SR > 門檻 AND CR < 40% AND TO < 30%，需連續 5 次通過。
降級條件: SR < 15% OR CR > 70% OR TO > 65%（一次即降）。

---

## 6. Reward 設計

### 6.1 NavRL Dense (current baseline)

| 項目 | 函數 | Weight | 數學定義 |
|------|------|--------|---------|
| reaching_goal | reaching_goal | +500 | 1.0 if dist < 0.35m, else 0 |
| velocity_to_goal | velocity_to_goal_reward | +15 | clamp(v_toward/v_max, -1, 1) × v_gate |
| safety_log_distance | safety_log_distance_reward | +3 | clamp(ln(d_safe), -6, 2) × speed_factor |
| safe_progress | safe_progress_reward | +20 | clamp(d_prev - d_curr, -1, 1) × gate |
| collision_terminal | collision_terminal_penalty | -100 | 1.0 if LiDAR_min ≤ 0.45m |
| acceleration_penalty | deadzone_acceleration_penalty | -0.05 | max(0, \|a\| - 0.1)² |
| angular_velocity_penalty | context_aware_angular_velocity_penalty | -0.05 | ω² × (1 - proximity_factor) |

**v_gate**: `clamp((d_safe - 1.0) / 1.5, 0, 1)` — d_safe < 1.0 → **完全關閉**
**safe_progress gate**: d_safe < 0.8 → **-0.5** (前進扣分、撤退加分)
**speed_factor**: `clamp(speed / 0.1, 0.1, 1.0)` — 靜止時衰減 90%

### 6.2 NavRL-Ground v1 (新版)

| 項目 | 函數 | Weight | 數學定義 |
|------|------|--------|---------|
| reaching_goal | reaching_goal | +500 | 同上 |
| goal_velocity | goal_velocity_reward | +10 | raw × soft_gate; soft_gate = 0.2 + 0.8×clamp((d_safe-0.6)/1.4, 0, 1) |
| goal_progress | goal_progress_reward | +12 | progress × soft_scale; soft_scale = 0.3 + 0.7×clamp((d_safe-0.5)/1.5, 0, 1) |
| static_safety | static_safety_reward | +3 | mean(ln(clearance_72bins)) + front_block_penalty |
| dynamic_safety | dynamic_safety_reward | +4 | mean_visible(ln(obstacle_clearance)) |
| smoothness | control_smoothness_penalty | -0.05 | dv² + dw² |
| time_penalty | per_step_time_penalty | -0.1 | -1 per step |
| collision | collision_terminal_penalty | -100 | 同上 |

**soft_gate**: 最低 beta=0.2，**永不歸零**
**soft_scale**: 最低 gamma=0.3，**永不翻負**
**static_safety**: 使用 72 bins 方向性 + 前向堵塞懲罰
**dynamic_safety**: per-obstacle log clearance，獨立於 d_safe

### 6.3 Terminal 條件對應的 reward

| 終止條件 | 函數 | 門檻 | 給 reward? |
|---------|------|------|-----------|
| goal_reached | goal_reached | dist < 0.35m | +500 × dt |
| collision (LiDAR) | collision_occurred | LiDAR_min ≤ 0.45m | -100 × dt |
| wall_collision | wall_collision_termination | AABB dist < 0.45m | 無獨立 reward |
| physics_explosion | physics_explosion | vel > 10 m/s 或 NaN | 無 |
| timeout | time_out | episode_length_s | bootstrap value |

---

## 7. 終止條件

| 條件 | 門檻 | 類型 | Bootstrap |
|------|------|------|-----------|
| time_out | episode_length_s (45~90s) | Truncation | Yes |
| goal_reached | dist < 0.35m | Success | No |
| collision_occurred | LiDAR 2D min ≤ 0.45m | Failure | No |
| wall_collision | AABB dist < 0.45m | Failure (safety net) | No |
| robot_tipped_over | Z-axis < 0.5 | Failure | No |
| physics_explosion | vel > 10 m/s 或 NaN | Failure | No |

---

## 8. 診斷指標定義

### 8.1 AblationMetricsLogger (15 指標)

| # | WandB Key | 定義 | 分母 |
|---|-----------|------|------|
| 1 | ablation/stuck_count | 連續 ≥5 步 speed<0.02 m/s 且 goal_dist 變化<0.01m | 累計次數 |
| 2 | ablation/freeze_ratio | speed<0.02 的步數 | / total_steps |
| 3 | ablation/oscillation_score | v_toward 符號在 10 步窗口內翻轉比例 | / sign_checks |
| 4 | ablation/retreat_ratio | d_safe<1.5 時 v_toward<0 的步數 | / near_obs_steps |
| 5 | ablation/progress_near_obs | d_safe<1.5 時的 progress 平均 | mean |
| 6 | ablation/v_toward_near_obs | d_safe<1.5 時的 v_toward 平均 | mean |
| 7 | ablation/shield_rate | shield 介入步數 | / total_steps |
| 8 | ablation/action_override_rate | shield 實際改動速度的步數 | / total_steps |
| 9 | ablation/d_safe_mean | 全局 d_safe 平均 | mean |
| 10 | ablation/d_safe_min | rollout 中最小 d_safe | min |
| 11 | ablation/danger_ratio | d_safe<0.8 的步數 | / total_steps |
| 12 | ablation/speed_near_obs | d_safe<1.5 時平均速度 | mean |
| 13 | ablation/front_clearance | 前方扇區平均距離 | mean |
| 14 | ablation/avg_ep_length | episode 平均長度 (steps) | mean |
| 15 | ablation/collision_ep_len | 碰撞終止的 episode 平均長度 | mean |

### 8.2 Curriculum 指標

| WandB Key | 定義 |
|-----------|------|
| Curriculum / stage | 當前課程階段 (1-8) |
| Curriculum / success_rate | 滑動窗口 SR (窗口大小=max(2000, n_envs×5)) |
| Curriculum / collision_rate | 滑動窗口 CR |
| Curriculum / timeout_rate | 滑動窗口 TO |
| Curriculum / dynamic_sr | 僅動態環境的 SR |
| Curriculum / sr_gap | SR - 升級門檻（>0 = 已達標） |
| Curriculum / upgrade_pass_count | 連續通過次數 (/ 5) |
| Curriculum / window_fill | 窗口填充率 (len/capacity) |
| Curriculum / approx_rollout_cycles | 階段內 PPO updates 近似值 |

### 8.3 Module Entropy Monitor

| WandB Key | 定義 |
|-----------|------|
| train/module_entropy | log10(actor_grad_norm / critic_grad_norm) |
| train/actor_grad_norm | Actor 梯度 L2 norm |
| train/critic_grad_norm | Critic 梯度 L2 norm |

解讀: >1.0 = Policy 更新過度; ≈0 = 平衡; <-3 = Policy 凍結

---

## 附錄 A: 關鍵檔案路徑

```
source/isaaclab_tasks/.../charge_skrl/
├── __init__.py                              # Task registration
├── cfg/
│   ├── charge_cfg.py                        # Robot USD config
│   ├── charge_env_cfg_vlp16.py              # Base VLP16 config
│   └── charge_env_cfg_vlp16_curriculum.py   # Curriculum + NavRL + Ground configs
├── mdp/
│   ├── rewards/
│   │   ├── navrl_rewards.py                 # NavRL dense rewards (current)
│   │   ├── navrl_ground_rewards.py          # NavRL-Ground v1 rewards (new)
│   │   ├── potential_based_rewards.py       # PBRS + collision
│   │   ├── smoothness_rewards.py            # Deadzone accel + context-aware ω
│   │   └── gap_rewards.py                   # Gap-seeking rewards
│   ├── observations/obs_functions.py        # 139D observation pipeline
│   ├── actions/
│   │   ├── discrete_differential_drive.py   # MultiDiscrete([19,19]) action
│   │   └── safety_shield.py                # Safety shield action
│   ├── terminations/
│   │   ├── goal.py                         # Goal reached + timeout
│   │   └── robot_state.py                  # Tipped/flying/explosion/wall collision
│   ├── events/
│   │   ├── mixed_parallel.py               # Obstacle randomization
│   │   ├── walls.py                        # Per-env wall randomization
│   │   └── reset.py                        # Safe position reset
│   └── wall_layout.py                      # Wall geometry + GPU queries
├── curriculum/goal_obstacle_curriculum.py   # 8-stage curriculum
├── goal_command.py                         # Multi-goal command
├── multi_goal_command.py                   # Multi-goal extension
├── domain_randomization/dr_events.py       # Physics/sensor DR
└── agents/skrl_ppo_cfg_vlp16.yaml          # PPO hyperparameters

scripts/reinforcement_learning/skrl/
├── train_charge_ac.py                      # Main training entry
├── wandb_trainer.py                        # WandB integration
├── vlp16_models.py                         # 3-branch network
├── console_summary.py                      # Terminal summary
└── diagnostics/ablation_metrics.py         # 15 behavioral metrics
```

## 附錄 B: Git 資訊

```bash
git remote: git@github.com:me0608623/charge_skrl.git
git branch: curriculum_navrl_reward
git log --oneline -5  # 查看最近 commits
```
